const inputs = document.querySelectorAll('input');

const patterns = {
    name: /^[a-zA-Z\d]{1,15}$/,
    subject: /^[a-zA-Z\d-]{1,30}$/,
    message: /^[a-z\d-]{8,225}$/,
    email: /^([a-z\d\.-]+)@([a-z\d-]+)\.([a-z]{2,8})(\.[a-z]{2,8})?$/
};

function validate(field, regex) {
    if (regex.test(field.value)) {
        field.className = 'valid col-lg-12';
    } else {
        field.className = 'invalid col-lg-12';
    }
}

inputs.forEach(input => {
    input.addEventListener('keyup', e => {
        validate(e.target, patterns[e.target.name]);
    });
});
const contact_btn = document.querySelector('.contact-but')
contact_btn.addEventListener('click', () => {
    let invalid =document.querySelectorAll('.invalid')
    let a = invalid.length
    if (a == 0) {

        let name = document.querySelector('#name').value
        let email = document.querySelector('#email').value
        let subject = document.querySelector('#subject').value
        let message = document.querySelector('#comment').value
        let data = new FormData();
        

        data.append('name', name);
        data.append('email', email);
        data.append('subject', subject);
        data.append('message', message);


        fetch('contact.php', {
            method: 'POST',
            body: data
        }).then((response) => {
            return response.text()
        }).then((res) => {
            if(res==='true'){
                alert('Your message has been sent successfully')
            }
            else if(res === 'false'){
                alert('Failed to send message, please try again')
            }
            else{
                alert('Something went wrong, please try again')
            }
        })
    }
    else{
        invalid.forEach(inval =>{
            inval.style.backgroundColor='#ffa2a2'
        })
    }
})